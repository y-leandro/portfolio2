package com.example.silonic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class gatobanda extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gatobanda);
        getSupportActionBar().hide();
    }

    public void abrirCalc(View v){
        Intent j = new Intent(this, calculadoramaluquinha.class);
        startActivity(j);
    }

}


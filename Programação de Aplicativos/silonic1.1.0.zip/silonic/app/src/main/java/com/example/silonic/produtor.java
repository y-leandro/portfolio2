package com.example.silonic;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class produtor extends AppCompatActivity
{
    EditText    busca;
    TextView    resultado;
    static      ArrayList<user> membrosBanda;
    user        encontrado = new  user();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produtor);
        getSupportActionBar().hide();

        busca       = findViewById(R.id.buscarTXT);
        resultado   = findViewById(R.id.resultTXT);

    }
    public void busca(View v)
    {
        String login = busca.getText().toString();
        String msg = "Login "+login+" não encontrado.";
        for(user u: membrosBanda)
        {
            if(u.login.equals(login))
            {
                encontrado = u;
                msg = login+" é um membrobanda.";
                break;
            }
        }
        resultado.setText(msg);

    }

}
package com.example.silonic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText campo,login,senha;
    ArrayList<user> membrosBanda = new ArrayList<>();




    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        campo = findViewById(R.id.TXTname);
        login = findViewById(R.id.TXTname);
        senha = findViewById(R.id.TXTsenha);

        adduser();

    }

    private void adduser() {
        user u1 = new user("produtor", "dono", true);
        user u2 = new user("gatoguitar", "amorock","guitarrista", false);
        user u3 = new user("gatobatera", "acimademimsodeuseasbaquetas", "baterista", false);
        user u4 = new user("1", "1", "baixista", false);
        user u5 = new user("gatocantor", "nomicsomandofree","cantor", false);

        membrosBanda.add(u1);
        membrosBanda.add(u2);
        membrosBanda.add(u3);
        membrosBanda.add(u4);
        membrosBanda.add(u5);
    }


    public void telacadastro (View v){
        Intent j = new Intent(this, naogatobanda.class);
        startActivity(j);
        naogatobanda.membrosBanda = membrosBanda;
    }


    public void logar(View v){
        String user = login.getText().toString();
        String pass = senha.getText().toString();
        String msg = "Olá " +", seja bem vindo à banda";
        for(user u: membrosBanda){
            if(user.equals(u.getLogin())&& pass.equals(u.getSenha())){
                if(u.isAdm()){
                    produtor.membrosBanda = membrosBanda;
                    Intent i = new Intent(this, produtor.class);
                    startActivity(i);
                }else{
                    Intent i = new Intent(this, gatobanda.class);
                    startActivity(i);
                }
                msg = "Olá " +u.getLogin() + ", seja bem vindo à banda";
                break;
            }
            else{
                msg = "Infelizmente você não faz parte da banda...";
            }
        }

        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

    }



}
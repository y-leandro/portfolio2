package com.example.silonic;

public class user {
    String login;
    String senha;
    String abc;
    boolean adm;

    public user(String login, String senha, String abc, boolean adm) {
        this.login = login;
        this.senha = senha;
        this.abc = abc;
        this.adm = adm;
    }
    public user() {

    }

    public user(String login, String senha, boolean adm) {
        this.login = login;
        this.senha = senha;
        this.adm = adm;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public boolean isAdm() {
        return adm;
    }

    public void setAdm(boolean adm) {
        this.adm = adm;
    }
}

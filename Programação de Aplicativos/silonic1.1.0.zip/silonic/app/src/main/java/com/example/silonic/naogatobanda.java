package com.example.silonic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class naogatobanda extends AppCompatActivity {
    static ArrayList<user> membrosBanda;
    EditText nl, ns, c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_naogatobanda);
        getSupportActionBar().hide();
        nl  = findViewById(R.id.novologin);
        ns  = findViewById(R.id.novasenha);
        c   = findViewById(R.id.confirmacao);


    }
    public void cadastro(View v){
        String login    = nl.getText().toString();
        String senha    = ns.getText().toString();
        String confirma = c.getText().toString();


        if (verificalogin()) {

            if (login.isEmpty()) {
                Toast.makeText(this, "Campo vazio.", Toast.LENGTH_SHORT).show();
            } else if (senha.isEmpty()) {
                Toast.makeText(this, "Campo vazio.", Toast.LENGTH_SHORT).show();
            } else if (senha.equals(confirma)) {
                user u = new user(login, senha, false);
                membrosBanda.add(u);
                Toast.makeText(this, "Cadastrado.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Login já existe.", Toast.LENGTH_SHORT).show();

        }

    }


    public boolean verificalogin() {
        String login = nl.getText().toString();;
        for (user u : membrosBanda) {
            if (login.equals(u.getLogin())) {
                return false;
            }
        }
        return true;
    }

}
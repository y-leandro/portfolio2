
package objetos;


public class treinoalunos {
    String  treino_A;
    String  treino_B;
    String  treino_C;
    String  treino_D;
    String  pesoAtual;
    String  pesoMeta;
    String  dataInicio;
    String  dataFinal;

    public treinoalunos(String treino_A, String treino_B, String treino_C, String treino_D, String pesoAtual, String pesoMeta, String dataInicio, String dataFinal) {
        this.treino_A = treino_A;
        this.treino_B = treino_B;
        this.treino_C = treino_C;
        this.treino_D = treino_D;
        this.pesoAtual = pesoAtual;
        this.pesoMeta = pesoMeta;
        this.dataInicio = dataInicio;
        this.dataFinal = dataFinal;
    }

    public treinoalunos() {
    }

    public String getTreino_A() {
        return treino_A;
    }

    public void setTreino_A(String treino_A) {
        this.treino_A = treino_A;
    }

    public String getTreino_B() {
        return treino_B;
    }

    public void setTreino_B(String treino_B) {
        this.treino_B = treino_B;
    }

    public String getTreino_C() {
        return treino_C;
    }

    public void setTreino_C(String treino_C) {
        this.treino_C = treino_C;
    }

    public String getTreino_D() {
        return treino_D;
    }

    public void setTreino_D(String treino_D) {
        this.treino_D = treino_D;
    }

    public String getPesoAtual() {
        return pesoAtual;
    }

    public void setPesoAtual(String pesoAtual) {
        this.pesoAtual = pesoAtual;
    }

    public String getPesoMeta() {
        return pesoMeta;
    }

    public void setPesoMeta(String pesoMeta) {
        this.pesoMeta = pesoMeta;
    }

    public String getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(String dataInicio) {
        this.dataInicio = dataInicio;
    }

    public String getDataFinal() {
        return dataFinal;
    }

    public void setDataFinal(String dataFinal) {
        this.dataFinal = dataFinal;
    }
    
    

   
}
